#!/bin/bash
set -euxo pipefail;
source "/usr/share/pedrazamx-gbagame-devenv-local/install/common.sh";

# Ask for parameters if not provided in environment variables.
_read_parameter "Git User Full Name: " "GBAGAME_GIT_USER_FULL_NAME" "John Smith";
_read_parameter "Git User Email: " "GBAGAME_GIT_USER_EMAIL" "john.smith@company.com";
_read_parameter "Git User Name: " "GBAGAME_GIT_USER_NAME" "john.smith";
_read_parameter "Git User PAT: " "GBAGAME_GIT_USER_PAT" "";

# Install required Microsotf VSCode Plugins.
code --install-extension ms-vscode.cpptools-extension-pack || true;
code --install-extension matepek.vscode-catch2-test-adapter || true;
_backup ~/.gdbinit;
cp "/usr/share/pedrazamx-gbagame-devenv-local/install/.gdbinit" ~/;

# Configure git.
mkdir -p ~/Projects && cd ~/Projects;
git config --global user.name "${GBAGAME_GIT_USER_FULL_NAME}";
git config --global user.email "${GBAGAME_GIT_USER_EMAIL}";
_backup gbagame;
git clone "https://${GBAGAME_GIT_USER_NAME}:${GBAGAME_GIT_USER_PAT}@github.com/alfpedraza/gbagame.git";
