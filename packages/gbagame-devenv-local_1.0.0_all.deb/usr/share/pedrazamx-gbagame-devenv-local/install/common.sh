#!/bin/bash

_read_parameter() {
    local prompt="$1";
    local parameter="$2";
    local default="$3";
    local value="";
    if [ -z "${!parameter}" ]; then read -e -p "${prompt}" -i "${default}" value; export ${parameter}=${value}; fi;
}

_backup() {
    local file="$1";
    local timestamp=$(date +"%Y%m%d%H%M%S");
    if [ -e "${file}" ]; then mv "${file}" "${file}_old_${timestamp}"; fi;
}


_remove() {
    local current="$1";
    local base_name="$(basename "${current}")";
    local dir="$(dirname "${current}")";
    local recent=$(find "${dir}" -maxdepth 1 -name "${base_name}_old_*" | sort -r | head -n1);
    if [ -e "${current}" ]; then sudo rm -rf "${current}"; fi;
    if [ ! -z "${recent}" ]; then sudo mv "${recent}" "${current}"; fi;
}
