#!/bin/bash
set -euxo pipefail;
source "/usr/share/pedrazamx-gbagame-devenv-local/install/common.sh";

# Uninstall the required Microsotf VSCode Plugins.
_remove ~/.gdbinit;
code --uninstall-extension ms-vscode.cpptools-extension-pack || true;
code --uninstall-extension matepek.vscode-catch2-test-adapter || true;
